select *from student
select *from CLASS
select *from SCORE
select *from TEACHER
select *from BOARD
select *from BOARDMANAGER

select *from SCORE
select avg(sco_score) from SCORE where stu_id= 'b1';
select sco_score from SCORE where stu_id= 'b1';

select sco_score from SCORE where stu_id= 'b1';
select max(bd_number) from BOARD

SELECT B.stu_name,A.sco_subject,A.sco_score FROM score A, Student B WHERE A.stu_id=B.stu_id and B.tea_id = 'a1';

select s.student_id, s.student_name, s.height,d.department_name
from student s, department d
where s.department_id = d.department_id and d.department_name = '������Ű�'

update STUDENT set stu_meet='1' where stu_id='b1';

select b.bd_number,b.bd_content from BOARDMANAGER bm,Board b where b.bd_number=bm.bd_number and bm.stu_id='b1' order by b.bd_number;
--
select sco_number from Score where
select max(sco_number) from Score