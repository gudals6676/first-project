package c;

import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import DaoVo.TeacherDAO;
import DaoVo.TeacherVO;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.CardLayout;
import java.awt.Color;

public class P2_4Teacher_GUI_1 {

	JFrame frame;
	TeacherDAO dao = null;
	String qwe = "";
	String id = "";
	JTextField textField;
	ArrayList<TeacherVO> al = null;
	private JTextField textField_1;

	ImageIcon imgmain = new ImageIcon("img/�л� ��ȸ.png");
	Image C_imgmain = imgmain.getImage().getScaledInstance(155, 61, Image.SCALE_SMOOTH);// �̹���ũ�� ��ȯ
	ImageIcon CI_imgmain = new ImageIcon(C_imgmain);

	ImageIcon imghome = new ImageIcon("img/home.png");
	Image C_imghome = imghome.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);// �̹���ũ�� ��ȯ
	ImageIcon CI_imghome = new ImageIcon(C_imghome);

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					String id = "a1";
					P2_4Teacher_GUI_1 window = new P2_4Teacher_GUI_1(id);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public P2_4Teacher_GUI_1() {
		initialize();
		frame.setVisible(true);
	}

	public P2_4Teacher_GUI_1(String id) {
		System.out.println();
		this.id = id;
		initialize();
		frame.setVisible(true);
	}

	public void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(0, 139, 205));
		frame.setBounds(600, 300, 700, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JPanel panel0 = new JPanel();
		panel0.setBackground(new Color(255, 255, 255));
		panel0.setBounds(250, 30, 150, 60);
		frame.getContentPane().add(panel0);
		panel0.setLayout(new CardLayout(0, 0));

		JLabel mainImage0 = new JLabel("");
		panel0.add(mainImage0, "name_27704402491100");
		mainImage0.setBackground(new Color(255, 255, 255));
		mainImage0.setIcon(CI_imgmain);

		// Ȩ ��ư
		JPanel panel_home = new JPanel();
		panel_home.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new P2_0TeacherMain(id);
				frame.dispose();
			}
		});
		panel_home.setBackground(Color.WHITE);
		panel_home.setBounds(30, 30, 45, 45);
		frame.getContentPane().add(panel_home);

		JLabel mainImagehome = new JLabel("");
		panel_home.add(mainImagehome, "name_27704402491100");
		mainImagehome.setBackground(new Color(255, 255, 255));
		mainImagehome.setIcon(CI_imghome);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(482, 117, 182, 210);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);

		JLabel stu_id = new JLabel(" �л� ID");
		stu_id.setBounds(-6, 0, 91, 21);
		stu_id.setFont(new Font("���� ����", Font.BOLD, 15));
		panel_1.add(stu_id);

		JLabel stu_id1 = new JLabel("");
		stu_id1.setBounds(91, 0, 91, 21);
		stu_id1.setFont(new Font("���� ����", Font.PLAIN, 15));
		panel_1.add(stu_id1);

		JLabel s_tea_id = new JLabel(" ��� ������ ID");
		s_tea_id.setBounds(-5, 21, 91, 21);
		s_tea_id.setFont(new Font("���� ����", Font.BOLD, 15));
		s_tea_id.setHorizontalAlignment(SwingConstants.LEFT);
		panel_1.add(s_tea_id);

		JLabel s_tea_id1 = new JLabel("");
		s_tea_id1.setBounds(91, 21, 91, 21);
		s_tea_id1.setFont(new Font("���� ����", Font.PLAIN, 15));
		panel_1.add(s_tea_id1);

		JLabel s_Class_number = new JLabel("�� �̸�");
		s_Class_number.setBounds(0, 42, 91, 21);
		s_Class_number.setFont(new Font("���� ����", Font.BOLD, 15));
		panel_1.add(s_Class_number);

		JLabel s_Class_number1 = new JLabel("");
		s_Class_number1.setBounds(91, 42, 91, 21);
		s_Class_number1.setFont(new Font("���� ����", Font.PLAIN, 15));
		panel_1.add(s_Class_number1);

		JLabel stu_pw = new JLabel("�л���й�ȣ");
		stu_pw.setBounds(0, 63, 91, 21);
		stu_pw.setFont(new Font("���� ����", Font.BOLD, 15));
		panel_1.add(stu_pw);

		JLabel stu_pw1 = new JLabel("");
		stu_pw1.setBounds(91, 63, 91, 21);
		stu_pw1.setFont(new Font("���� ����", Font.PLAIN, 15));
		panel_1.add(stu_pw1);

		JLabel stu_name = new JLabel("�л��̸�");
		stu_name.setBounds(0, 84, 91, 21);
		stu_name.setFont(new Font("���� ����", Font.BOLD, 15));
		panel_1.add(stu_name);

		JLabel stu_name1 = new JLabel("");
		stu_name1.setBounds(91, 84, 91, 21);
		stu_name1.setFont(new Font("���� ����", Font.PLAIN, 15));
		panel_1.add(stu_name1);

		JLabel stu_birthday = new JLabel("����");
		stu_birthday.setBounds(0, 105, 91, 21);
		stu_birthday.setFont(new Font("���� ����", Font.BOLD, 15));
		panel_1.add(stu_birthday);

		JLabel stu_birthday1 = new JLabel("");
		stu_birthday1.setBounds(91, 105, 91, 21);
		stu_birthday1.setFont(new Font("���� ����", Font.PLAIN, 15));
		panel_1.add(stu_birthday1);

		JLabel stu_tel = new JLabel("��ȭ��ȣ");
		stu_tel.setBounds(0, 126, 91, 21);
		stu_tel.setFont(new Font("���� ����", Font.BOLD, 15));
		panel_1.add(stu_tel);

		JLabel stu_tel1 = new JLabel("");
		stu_tel1.setBounds(91, 126, 91, 21);
		stu_tel1.setFont(new Font("���� ����", Font.PLAIN, 15));
		panel_1.add(stu_tel1);

		JLabel stu_address = new JLabel("�ּ�");
		stu_address.setBounds(0, 147, 91, 21);
		stu_address.setFont(new Font("���� ����", Font.BOLD, 15));
		panel_1.add(stu_address);

		JLabel stu_address1 = new JLabel("");
		stu_address1.setBounds(91, 147, 91, 21);
		stu_address1.setFont(new Font("���� ����", Font.PLAIN, 15));
		panel_1.add(stu_address1);

		JLabel stu_email = new JLabel("E-mail");
		stu_email.setBounds(1, 168, 91, 21);
		stu_email.setFont(new Font("���� ����", Font.BOLD, 15));
		panel_1.add(stu_email);

		JLabel stu_email1 = new JLabel("");
		stu_email1.setBounds(91, 168, 91, 21);
		stu_email1.setFont(new Font("���� ����", Font.PLAIN, 15));
		panel_1.add(stu_email1);

		JLabel stu_meet = new JLabel("\uD559\uC0DD \uBA74\uB2F4");
		stu_meet.setBounds(0, 189, 91, 21);
		stu_meet.setFont(new Font("���� ����", Font.BOLD, 15));
		panel_1.add(stu_meet);

		JLabel stu_meet1 = new JLabel("");
		stu_meet1.setBounds(91, 189, 91, 21);
		stu_meet1.setFont(new Font("���� ����", Font.PLAIN, 15));
		panel_1.add(stu_meet1);
		// ������ �޾ƿ��� �κ�
		TeacherDAO dao = new TeacherDAO();
		al = dao.teacher_STUDENT_noselect();

		String[] header = { "�л�_id", "���Ӽ�����_id", "�ݹ�ȣ", "��й�ȣ", "�̸�", "����", "��ȭ��ȣ", "�ּ���", "�̸���", "���", };
		// Ŀ����(������) -2���� �迭
		String[][] data1 = new String[al.size()][11]; // ǥ���ϰ� ���� ���� ǥ��
		for (int i = 0; i < al.size(); i++) {
			for (int j = 0; j <= 9; j++) {
				if (j == 0) {
					data1[i][j] = al.get(i).getStu_id();
				} else if (j == 1) {
					data1[i][j] = al.get(i).getS_tea_id();
				} else if (j == 2) {
					data1[i][j] = al.get(i).getS_Class_number();
				} else if (j == 3) {
					data1[i][j] = al.get(i).getStu_pw();
				} else if (j == 4) {
					data1[i][j] = al.get(i).getStu_name();
				} else if (j == 5) {
					data1[i][j] = al.get(i).getStu_birthday();
				} else if (j == 6) {
					data1[i][j] = al.get(i).getStu_tel();
				} else if (j == 7) {
					data1[i][j] = al.get(i).getStu_address();
				} else if (j == 8) {
					data1[i][j] = al.get(i).getStu_email();
				} else if (j == 9) {
					data1[i][j] = al.get(i).getStu_meet();
				}
			}
		}

		JPanel panel = new JPanel();
		panel.setBounds(17, 123, 456, 283);
		frame.getContentPane().add(panel);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(33, 403, 398, -278);
		panel.add(scrollPane);
		// ���̺� ����
		////////////////////////////////////////
		JTable table = new JTable(data1, header);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				String stu_id = (String) table.getModel().getValueAt(row, 0);
				String s_tea_id = (String) table.getModel().getValueAt(row, 1);
				String s_Class_number = (String) table.getModel().getValueAt(row, 2);
				String stu_pw = (String) table.getModel().getValueAt(row, 3);
				String stu_name = (String) table.getModel().getValueAt(row, 4);
				String stu_birthday = (String) table.getModel().getValueAt(row, 5);
				String stu_tel = (String) table.getModel().getValueAt(row, 6);
				String stu_address = (String) table.getModel().getValueAt(row, 7);
				String stu_email = (String) table.getModel().getValueAt(row, 8);
				String stu_meet = (String) table.getModel().getValueAt(row, 9);
				
				stu_id1.setText(stu_id);
				s_tea_id1.setText(s_tea_id);
				s_Class_number1.setText(s_Class_number);
				stu_pw1.setText(stu_pw);
				stu_name1.setText(stu_name);
				stu_birthday1.setText(stu_birthday);
				stu_tel1.setText(stu_tel);
				stu_address1.setText(stu_address);
				stu_email1.setText(stu_email);
				stu_meet1.setText(stu_meet);
				
			}
		});
		// �г� ��ü�� ���̺��� ������ ����� ������
		table.setFillsViewportHeight(true);
		// ���̺��� ��ũ�� �гο� �߰�, �÷��̸��� ���̱� ���ؼ� �߰�
		scrollPane.setViewportView(table);
		// Ư���л��� ������ ��ȸ���ִ� �κ�
		JButton btnNewButton = new JButton("\uB2F4\uB2F9 \uD559\uC0DD \uC810\uC218 \uC870\uD68C");
		btnNewButton.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton.addActionListener(new ActionListener() {// ������ȸ
			public void actionPerformed(ActionEvent e) {
				new P2_5Teacher_GUI_2(id);
				frame.dispose();
				// ������ ��ȸ�ϴºκ��� �ҷ����� ������
			}
		});
		btnNewButton.setBounds(482, 401, 182, 23);
		frame.getContentPane().add(btnNewButton);

		textField = new JTextField();
		textField.setBounds(482, 337, 83, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);

		// �л� ������ �̸��� �Ű�ü�� ������ �˻��ؼ� ����û����
		JButton btnNewButton_1 = new JButton("\uBA74\uB2F4 \uC2E0\uCCAD");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = textField.getText();
				if (name == null) {
					JOptionPane.showMessageDialog(null, "�Է°��� �־��ּ���", "�Է°� ����", JOptionPane.ERROR_MESSAGE);
				} else {
					dao.teacher_student_UPDATE(name);
					// ���ΰ�ħ �ϴ� �κ� (â ���� �ٽ� ����)
					JOptionPane.showMessageDialog(null, " ����û�� �Ϸ�Ǿ����ϴ�","��� ����",JOptionPane.ERROR_MESSAGE);
					new P2_4Teacher_GUI_1(id);
					frame.dispose();
				}
			}
		});

		btnNewButton_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_1.setBounds(577, 337, 87, 23);
		frame.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("\uAC1C\uBCC4\uC870\uD68C");
		btnNewButton_2.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = textField_1.getText();
				new P2_6TeacherS(id, name);
			}
		});
		btnNewButton_2.setBounds(577, 368, 87, 23);
		frame.getContentPane().add(btnNewButton_2);

		textField_1 = new JTextField();
		textField_1.setBounds(482, 369, 83, 21);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);

		JPanel panel_11 = new JPanel();
		panel_11.setBackground(new Color(255, 255, 255));
		panel_11.setBounds(15, 17, 652, 426);
		frame.getContentPane().add(panel_11);
		panel_11.setLayout(null);

	}
}
