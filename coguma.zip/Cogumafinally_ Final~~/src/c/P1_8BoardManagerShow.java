package c;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;

import DaoVo.bmDAO;
import DaoVo.bmVO;

public class P1_8BoardManagerShow {

	private JFrame frame;
	bmDAO dao = new bmDAO();
	ArrayList<bmVO> al = null;
	String id="";

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					String id="b1";
					P1_8BoardManagerShow window = new P1_8BoardManagerShow(id);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public P1_8BoardManagerShow() {
		initialize();
	}
	public P1_8BoardManagerShow(String id) {
		this.id=id;
		initialize();
		frame.setVisible(true);
	}

	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(0, 139, 205));
		frame.setBounds(800, 300, 235, 377);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		String[] header = { "��ȣ","������" };
		// Ŀ����(������) -2���� �迭
		al=dao.ShowBM(id);
		String[][] data = new String[al.size()][30]; // �޾ƿ� ���� ǥ���ϰ� ���� ���� ǥ����
		for (int i = 0; i < al.size(); i++) {
			for (int j = 0; j <= 2; j++) {
				if (j == 0) {
					data[i][j] = al.get(i).getBd_number();
					System.out.println(al.get(i).getBd_content());
				} else if (j == 1) {
					data[i][j] = al.get(i).getBd_content();
					System.out.println(al.get(i).getBd_content());
				}
			}
		}

		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(17, 49, 180, 260);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(-3, 0, 190, 279);
		panel.add(scrollPane);
		// ���̺� ����
		JTable table = new JTable(data, header);
		table.setCellSelectionEnabled(true);
		table.setColumnSelectionAllowed(true);
		// �г� ��ü�� ���̺��� ������ ����� ������
		table.setFillsViewportHeight(true);
		// ���̺��� ��ũ�� �гο� �߰�, �÷��̸��� ���̱� ���ؼ� �߰�
		scrollPane.setViewportView(table);
	///////////////////////�ڵ����߿� /////////////////////////////////	
		table.getColumn("��ȣ").setPreferredWidth(30);
		table.getColumn("������").setPreferredWidth(150);

		JLabel lblNewLabel = new JLabel("\uC2E0\uCCAD \uBAA9\uB85D");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(17, 10, 188, 40);
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 20));
		frame.getContentPane().add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(12, 10, 195, 318);
		frame.getContentPane().add(panel_1);
	}
}

