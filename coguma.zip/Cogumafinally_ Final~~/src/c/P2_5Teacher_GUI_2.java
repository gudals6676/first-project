package c;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import DaoVo.ScoreDAO;
import DaoVo.TeacherDAO;
import DaoVo.TeacherVO;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class P2_5Teacher_GUI_2 {

	private JFrame frame;
	TeacherDAO dao = new TeacherDAO();
	ArrayList<TeacherVO> al = null;
	String id = "";
	ScoreDAO scDao= new ScoreDAO();
	String stu_name="";

	ImageIcon imgmain = new ImageIcon("img/���� ��ȸ.png");
	Image C_imgmain = imgmain.getImage().getScaledInstance(166, 53, Image.SCALE_SMOOTH);// �̹���ũ�� ��ȯ
	ImageIcon CI_imgmain = new ImageIcon(C_imgmain);

	ImageIcon imghome = new ImageIcon("img/home.png");
	Image C_imghome = imghome.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);// �̹���ũ�� ��ȯ
	ImageIcon CI_imghome = new ImageIcon(C_imghome);

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					String id = "a1";
					P2_5Teacher_GUI_2 window = new P2_5Teacher_GUI_2(id);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public P2_5Teacher_GUI_2() {
		initialize();
		frame.setVisible(true);
	}

	public P2_5Teacher_GUI_2(String id) {
		al = dao.teacher_calss_select(id); // �������� ���� �޾ƿ´�
		this.id = id;
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(0, 139, 205));
		frame.setBounds(600, 300, 700, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JPanel panel0 = new JPanel();
		panel0.setBackground(new Color(255, 255, 255));
		panel0.setBounds(250, 30, 170, 60);
		frame.getContentPane().add(panel0);
		panel0.setLayout(new CardLayout(0, 0));

		JLabel mainImage0 = new JLabel("");
		panel0.add(mainImage0, "name_27704402491100");
		mainImage0.setBackground(new Color(255, 255, 255));
		mainImage0.setIcon(CI_imgmain);
		
		// Ȩ ��ư
		JPanel panel_home = new JPanel();
		panel_home.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new P2_4Teacher_GUI_1(id);
				frame.dispose();
			}
		});
		panel_home.setBackground(Color.WHITE);
		panel_home.setBounds(30, 30, 45, 45);
		frame.getContentPane().add(panel_home);

		JLabel mainImagehome = new JLabel("");
		panel_home.add(mainImagehome, "name_27704402491100");
		mainImagehome.setBackground(new Color(255, 255, 255));
		mainImagehome.setIcon(CI_imghome);

		JPanel panel_11 = new JPanel();
		panel_11.setBackground(Color.WHITE);
		panel_11.setBounds(485, 130, 182, 210);
		frame.getContentPane().add(panel_11);
		panel_11.setLayout(new GridLayout(0, 2, 0, 0));

		JLabel stu_id = new JLabel("\uC774 \uB984");
		stu_id.setFont(new Font("���� ����", Font.BOLD, 18));
		panel_11.add(stu_id);

		JLabel stu_id1 = new JLabel("");
		stu_id1.setFont(new Font("���� ����", Font.PLAIN, 18));
		panel_11.add(stu_id1);

		JLabel sco_subject = new JLabel("\uACFC \uBAA9");
		sco_subject.setFont(new Font("���� ����", Font.BOLD, 18));
		panel_11.add(sco_subject);

		JLabel sco_subject1 = new JLabel("");
		sco_subject1.setFont(new Font("���� ����", Font.PLAIN, 18));
		panel_11.add(sco_subject1);

		JLabel sco_score = new JLabel("\uC810 \uC218");
		sco_score.setFont(new Font("���� ����", Font.BOLD, 18));
		panel_11.add(sco_score);

		JLabel sco_score1 = new JLabel("");
		sco_score1.setFont(new Font("���� ����", Font.PLAIN, 18));
		panel_11.add(sco_score1);

		String[] header = { "�̸�", "����", "����" };
		// Ŀ����(������) -2���� �迭
		String[][] data = new String[al.size()][4]; // �޾ƿ� ���� ǥ���ϰ� ���� ���� ǥ����
		for (int i = 0; i < al.size(); i++) {
			for (int j = 0; j <= 2; j++) {
				if (j == 0) {
					data[i][j] = al.get(i).getStu_name();
				} else if (j == 1) {
					data[i][j] = al.get(i).getSco_subject();
				} else if (j == 2) {
					data[i][j] = al.get(i).getSco_score();
				}
			}
		}

		JPanel panel = new JPanel();
		panel.setBounds(17, 123, 461, 283);
		frame.getContentPane().add(panel);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(33, 403, 398, -278);
		panel.add(scrollPane);
		// ���̺� ����
		JTable table = new JTable(data, header);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				stu_name = (String) table.getModel().getValueAt(row, 0);
				String sco_subject = (String) table.getModel().getValueAt(row, 1);
				String sco_score = (String) table.getModel().getValueAt(row, 2);

				stu_id1.setText(stu_name);
				sco_subject1.setText(sco_subject);
				sco_score1.setText(sco_score);

			}
		});
		// �г� ��ü�� ���̺��� ������ ����� ������
		table.setFillsViewportHeight(true);
		// ���̺��� ��ũ�� �гο� �߰�, �÷��̸��� ���̱� ���ؼ� �߰�
		scrollPane.setViewportView(table);
		

		JPanel panel_111 = new JPanel();
		panel_111.setBackground(new Color(255, 255, 255));
		panel_111.setBounds(15, 17, 652, 426);
		frame.getContentPane().add(panel_111);
		panel_111.setLayout(null);
		
		JButton btnNewButton = new JButton("\uC131\uC801\uC0AD\uC81C");
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setFont(new Font("���� ����", Font.PLAIN, 16));
		btnNewButton.setBounds(496, 366, 132, 31);
		panel_111.add(btnNewButton);
		
		JButton button = new JButton("\uC131\uC801\uCD94\uAC00");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new P2_9createScore(id);
			}
		});
		button.setBackground(Color.WHITE);
		button.setFont(new Font("���� ����", Font.PLAIN, 16));
		button.setBounds(496, 325, 132, 31);
		panel_111.add(button);

	}
}
