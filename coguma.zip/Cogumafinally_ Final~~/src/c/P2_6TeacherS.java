package c;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import DaoVo.TeacherDAO;
import DaoVo.TeacherVO;

public class P2_6TeacherS {

	private JFrame frame;
	TeacherDAO dao = new TeacherDAO();
	ArrayList<TeacherVO> al = null;
	String id="";
	
	ImageIcon imgmain = new ImageIcon("img/���� ���� ��ȸ.png");
	Image C_imgmain = imgmain.getImage().getScaledInstance(122, 22, Image.SCALE_SMOOTH);// �̹���ũ�� ��ȯ
	ImageIcon CI_imgmain = new ImageIcon(C_imgmain);

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					String id="a1";
					String name="������";
					P2_6TeacherS window = new P2_6TeacherS(id,name);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public P2_6TeacherS() {
		initialize();
	}
	public P2_6TeacherS(String id,String name) {
		this.id=id;
		al=dao.teacher_calss_S(id,name);
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(800, 300, 244, 421);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JPanel panel0 = new JPanel();
		panel0.setBackground(new Color(255, 255, 255));
		panel0.setBounds(50, 30, 122, 22);
		frame.getContentPane().add(panel0);
		panel0.setLayout(new CardLayout(0, 0));

		JLabel mainImage0 = new JLabel("");
		panel0.add(mainImage0, "name_27704402491100");
		mainImage0.setBackground(new Color(255, 255, 255));
		mainImage0.setIcon(CI_imgmain);
		
		String[] header = { "�̸�", "����", "����" };
		// Ŀ����(������) -2���� �迭
		String[][] data = new String[al.size()][4]; // �޾ƿ� ���� ǥ���ϰ� ���� ���� ǥ����
		for (int i = 0; i < al.size(); i++) {
			for (int j = 0; j <= 2; j++) {
				if (j == 0) {
					data[i][j] = al.get(i).getStu_name();
				} else if (j == 1) {
					data[i][j] = al.get(i).getSco_subject();
				} else if (j == 2) {
					data[i][j] = al.get(i).getSco_score();
				}
			}
		}

		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(17, 60, 188, 260);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(5, 5, 180, 240);
		panel.add(scrollPane);
		// ���̺� ����
		JTable table = new JTable(data, header);
		table.setCellSelectionEnabled(true);
		table.setColumnSelectionAllowed(true);
		// �г� ��ü�� ���̺��� ������ ����� ������
		table.setFillsViewportHeight(true);
		// ���̺��� ��ũ�� �гο� �߰�, �÷��̸��� ���̱� ���ؼ� �߰�
		scrollPane.setViewportView(table);
		
		JButton button = new JButton("\uB2EB\uAE30");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		button.setBackground(Color.WHITE);
		button.setFont(new Font("���� ����", Font.PLAIN, 18));
		button.setBounds(46, 325, 129, 25);
		frame.getContentPane().add(button);
	}
}
