package c;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import DaoVo.TeacherDAO;
import DaoVo.TeacherVO;

public class P2_1Classmgment_GUI {
   ArrayList<TeacherVO> al = new ArrayList<TeacherVO>();
   TeacherDAO dao= new TeacherDAO();
   private JFrame frame;
   private JTable table;
   String id;
   int selectRow=0;
   String num="";
   ImageIcon imgmain = new ImageIcon("img/�� ����.png");
   Image C_imgmain = imgmain.getImage().getScaledInstance(155, 61, Image.SCALE_SMOOTH);// �̹���ũ�� ��ȯ
   ImageIcon CI_imgmain = new ImageIcon(C_imgmain);

   ImageIcon imghome = new ImageIcon("img/home.png");
   Image C_imghome = imghome.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);// �̹���ũ�� ��ȯ
   ImageIcon CI_imghome = new ImageIcon(C_imghome);

   public static void main(String[] args) {
      EventQueue.invokeLater(new Runnable() {
         public void run() {
            try {
               String id = "a1";
               P2_1Classmgment_GUI window = new P2_1Classmgment_GUI(id);
               window.frame.setVisible(true);
            } catch (Exception e) {
               e.printStackTrace();
            }
         }
      });
   }

   public P2_1Classmgment_GUI(String id) {
      System.out.println(id);
      this.id = id;
      initialize();
      frame.setVisible(true);
   }

   /**
    * Initialize the contents of the frame.
    */
   private void initialize() {
      frame = new JFrame();
      frame.getContentPane().setBackground(new Color(0, 139, 205));
      frame.setBounds(600, 300, 700, 500);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.getContentPane().setLayout(null);

      // ���� ����
      JPanel panel0 = new JPanel();
      panel0.setBackground(new Color(255, 255, 255));
      panel0.setBounds(250, 30, 150, 60);
      frame.getContentPane().add(panel0);
      panel0.setLayout(new CardLayout(0, 0));

      JLabel mainImage0 = new JLabel("");
      panel0.add(mainImage0, "name_27704402491100");
      mainImage0.setBackground(new Color(255, 255, 255));
      mainImage0.setIcon(CI_imgmain);

      // Ȩ ��ư
      JPanel panel_home = new JPanel();
      panel_home.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            new P2_0TeacherMain(id);
            frame.dispose();
         }
      });
      panel_home.setBackground(Color.WHITE);
      panel_home.setBounds(30, 30, 45, 45);
      frame.getContentPane().add(panel_home);

      JLabel mainImagehome = new JLabel("");
      panel_home.add(mainImagehome, "name_27704402491100");
      mainImagehome.setBackground(new Color(255, 255, 255));
      mainImagehome.setIcon(CI_imghome);

      al = dao.selectClass();
      String[] header = { "�� ��ȣ", "�� �̸�", "��� ������_ID", "���� ���" };
      String[][] data = new String[al.size()][4];// 3:7

      for (int i = 0; i < al.size(); i++) {

         data[i][0] = al.get(i).getClass_Number();
         data[i][1] = al.get(i).getClass_className();
         data[i][2] = al.get(i).getC_tea_id();
         data[i][3] = al.get(i).getClass_branch();

      }

      JPanel panel_1 = new JPanel();
      panel_1.setBackground(new Color(255, 255, 255));
      panel_1.setBounds(21, 21, 640, 420);
      frame.getContentPane().add(panel_1);
      panel_1.setLayout(null);

      JButton btn_insert = new JButton("\uBC18 \uC0DD\uC131");
      btn_insert.addActionListener(new ActionListener() {
      	public void actionPerformed(ActionEvent arg0) {
      	}
      });
      btn_insert.setBackground(new Color(255, 255, 255));
      btn_insert.setBounds(512, 143, 97, 60);
      panel_1.add(btn_insert);
      btn_insert.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            new P2_2createClass();
         }
      });
      btn_insert.setFont(new Font("���� ����", Font.PLAIN, 16));
      /////////////// ����Ʈ 
      
      JButton btn_delete = new JButton("\uBC18 \uC0AD\uC81C");
      btn_delete.addActionListener(new ActionListener() {
      	public void actionPerformed(ActionEvent e) {
      	}
      });
      btn_delete.setBackground(new Color(255, 255, 255));
      btn_delete.setBounds(512, 213, 97, 60);
      panel_1.add(btn_delete);
      btn_delete.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            TeacherDAO dao= new TeacherDAO();
            System.out.println(num);
            int cnt = dao.deleteClass(num);
            if (cnt > 0) {
               JOptionPane.showMessageDialog(null, "�� �����Ϸ�!");
               frame.dispose();
               new P2_1Classmgment_GUI(id);
            } else {
               JOptionPane.showMessageDialog(null, "���� ����!");
            }
         }
      });

      btn_delete.setFont(new Font("���� ����", Font.PLAIN, 16));
      JScrollPane scrollPane = new JScrollPane();
      scrollPane.setBounds(34, 93, 452, 297);
      panel_1.add(scrollPane);

      JTable table_1 = new JTable(data, header);
      table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				selectRow = table_1.getSelectedRow();
				num = (String) table_1.getModel().getValueAt(selectRow, 0);
			}
		});
      table_1.setFillsViewportHeight(true);// �������ϱ�
      // ���̺��� ��ũ�� �г� �߰� ,, Į���̸� ���̱� ���ؼ� �߰� **
      scrollPane.setViewportView(table_1);

      JPanel panel = new JPanel();
      scrollPane.setColumnHeaderView(panel);

   }
}
