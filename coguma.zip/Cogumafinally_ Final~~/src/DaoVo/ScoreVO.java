package DaoVo;

public class ScoreVO {

}
