package DaoVo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Scanner;
import DaoVo.bmVO;

public class bmDAO {
	
	Connection conn = null;
	PreparedStatement psmt = null;
	int cnt = 0;
	String sql = "";
	bmVO vo = null;
	ResultSet rs = null;
	ArrayList<bmVO> arr;
	Scanner sc = new Scanner(System.in);
	// ���� ���������� ���� ����� �������� ���� �״�� ����..

	public void getcon() { // Ŀ�غκ�
		try {
			String url = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String dbid = "hr";
			String dbpw = "hr";
			conn = DriverManager.getConnection(url, dbid, dbpw);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	///////////////////////������� ����
	public ArrayList<bmVO> ShowBM(String id){
		String bdn;
		String bnc;
		arr= new ArrayList<bmVO>();
		try {
			getcon();
			sql="select b.bd_number,b.bd_content from BOARDMANAGER bm,Board b where b.bd_number=bm.bd_number and bm.stu_id=? order by b.bd_number";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, id); // 01�� ���� �޾ƾ���
			rs = psmt.executeQuery();
			while(rs.next()) {
				bdn = rs.getString(1);
				bnc = rs.getString(2);
				vo = new bmVO(bdn, bnc);
				
		
				arr.add(vo);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return arr;
	}


}
