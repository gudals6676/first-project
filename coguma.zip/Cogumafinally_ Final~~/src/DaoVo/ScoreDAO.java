package DaoVo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Scanner;

public class ScoreDAO {
	Connection conn = null;
	PreparedStatement psmt = null;
	int cnt = 0;
	String sql = "";
	TeacherVO vo = null;
	ResultSet rs = null;
	ArrayList<ScoreVO> arr = new ArrayList<ScoreVO>();
	Scanner sc = new Scanner(System.in);
	String d1="";
	int dI=0;
	String Scn="";
	public void getcon() { // Ŀ�غκ�
		try {
			String url = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
			Class.forName("oracle.jdbc.driver.OracleDriver");

			String dbid = "hr";
			String dbpw = "hr";
			conn = DriverManager.getConnection(url, dbid, dbpw);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	//S_id,Sc_date,Sc_sub,Sc_score
	public int Scinsert(String S_id,String Sc_date,String Sc_sub,String Sc_score) {
		try {
			getcon();
			sql = "select max(sco_number) from Score";		
			psmt = conn.prepareStatement(sql);

			rs = psmt.executeQuery();
			while (rs.next()) {
				d1 = rs.getString(1);
			}
			dI = Integer.parseInt(d1);
			dI += 1;
			if(dI<10) {
				Scn = Integer.toString(dI);
				Scn = "0"+Scn;
			}else {
				Scn = Integer.toString(dI);
			}
			
		} catch (Exception e) { 
			e.printStackTrace();
			System.out.println("1������");
		}
		try {
			//S_id,Sc_date,Sc_sub,Sc_score
			sql = "insert into Score values (?,?,?,?,?)";		
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, Scn);
			psmt.setString(2, S_id);
			psmt.setString(3, Sc_date);
			psmt.setString(4, Sc_sub);
			psmt.setString(5, Sc_score);
			
			cnt = psmt.executeUpdate();			
			if (cnt > 0) {
				System.out.println("���漺��2");
			} else {
				System.out.println("���ɽ���2");
			}
			
		} catch (Exception e) { 
			e.printStackTrace(); 
		}
		return cnt;
	}

}
