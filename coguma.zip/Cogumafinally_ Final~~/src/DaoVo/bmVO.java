package DaoVo;

public class bmVO {
	String bd_number;
	String bd_content;
	public bmVO(String bd_number, String bd_content) {
		super();
		this.bd_number = bd_number;
		this.bd_content = bd_content;
	}
	public String getBd_number() {
		return bd_number;
	}

	public String getBd_content() {
		return bd_content;
	}
	
}
